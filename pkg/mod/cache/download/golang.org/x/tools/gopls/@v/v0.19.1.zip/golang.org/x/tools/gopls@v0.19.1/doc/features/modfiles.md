# Gopls: Support for go.mod and go.work files

TODO: document these features for go.{mod,work} files:
- hover
- vulncheck
- add dependency
- update dependency
- diagnostics

